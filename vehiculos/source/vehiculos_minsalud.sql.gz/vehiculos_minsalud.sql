-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 02-12-2018 a las 05:23:06
-- Versión del servidor: 10.1.31-MariaDB
-- Versión de PHP: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `vehiculos_minsalud`
--

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `001_documentaciones`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `001_documentaciones` (
`documentacion_id` varchar(10)
,`documentacion_tmp_iniciador` varchar(100)
,`documentacion_tmp_asunto` text
,`documentacion_tmp_SYSusuario` varchar(20)
,`documentacion_tmp_estado` char(1)
,`documentacion_tipo_id` varchar(5)
,`documentacion_tipo_otro` varchar(50)
,`documentacion_numero` int(10)
,`documentacion_numero_ano` int(4)
,`documentacion_numero_documentacion_tipo_id` varchar(5)
,`documentacion_organismo_area_id` varchar(5)
,`iniciador_tipo` char(1)
,`iniciador_persona_id` varchar(6)
,`iniciador_persona_id_anterior` varchar(5)
,`iniciador_persona_id_nuevo` varchar(5)
,`iniciador_organismo_id` varchar(10)
,`iniciador_organismo_area_id` varchar(5)
,`iniciador_otro` varchar(100)
,`expediente_numero` int(5)
,`expediente_codigo` int(3)
,`expediente_ano` int(4)
,`expediente_fecha` date
,`expediente_SYSusuario` varchar(20)
,`expediente_estado` char(1)
,`expediente_estado_suspendido_hasta` date
,`expediente_estado_suspendido_hasta_SYSusuario` varchar(20)
,`documentacion_asunto` text
,`documentacion_asunto_tipo_id` varchar(5)
,`documentacion_asunto_tipo_otro` varchar(50)
,`documentacion_fecha_inicio` date
,`documentacion_fecha` date
,`documentacion_hora` time
,`documentacion_folios` int(6)
,`documentacion_SYSusuario` varchar(20)
,`glosado_a_documentacion_id` varchar(10)
,`glosados` text
,`_alta_id` varchar(27)
,`seguimiento_id` varchar(15)
,`referencia_de_busqueda` varchar(20)
,`id_formulario` int(11)
,`id_rendicion` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `001_documentaciones_tipos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `001_documentaciones_tipos` (
`documentacion_tipo_id` char(5)
,`documentacion_tipo` char(30)
,`documentacion_tipo_orden_aparicion` int(2)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `chofer`
--

CREATE TABLE `chofer` (
  `id_chofer` int(11) NOT NULL,
  `apenom` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `dni` varchar(8) COLLATE utf8_spanish_ci DEFAULT NULL,
  `email` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `observa` text COLLATE utf8_spanish_ci,
  `telefono` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `organismo_area_id` varchar(5) COLLATE utf8_spanish_ci DEFAULT NULL,
  `licencia_oficial` enum('S','N') COLLATE utf8_spanish_ci DEFAULT NULL COMMENT 'S, N',
  `id_tipo` int(11) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `f_emision` date DEFAULT NULL,
  `f_vencimiento` date DEFAULT NULL,
  `f_inscripcion` datetime DEFAULT NULL,
  `id_parque` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entsal`
--

CREATE TABLE `entsal` (
  `id_entsal` int(11) NOT NULL,
  `id_vehiculo` int(11) DEFAULT NULL,
  `observa` text COLLATE utf8_spanish_ci,
  `f_ent` datetime DEFAULT NULL,
  `id_usuario_ent` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `resp_ent` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `kilo` int(7) DEFAULT NULL,
  `cod_up` int(11) DEFAULT NULL,
  `f_sal` datetime DEFAULT NULL,
  `id_usuario_sal` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `resp_sal` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `total` decimal(9,2) DEFAULT NULL,
  `asunto` tinyint(1) DEFAULT NULL,
  `diferido` tinyint(1) DEFAULT NULL,
  `estado` enum('E','S','T','A') COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `incidente`
--

CREATE TABLE `incidente` (
  `id_incidente` int(11) NOT NULL,
  `id_chofer` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `descrip` text COLLATE utf8_spanish_ci,
  `id_tipo_incidente` int(11) DEFAULT NULL,
  `id_usuario` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimiento`
--

CREATE TABLE `movimiento` (
  `id_movimiento` int(11) NOT NULL,
  `id_entsal` int(11) DEFAULT NULL,
  `cod_razon_social` int(11) DEFAULT NULL,
  `observa` text COLLATE utf8_spanish_ci,
  `f_ent` datetime DEFAULT NULL,
  `id_usuario_ent` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `f_sal` datetime DEFAULT NULL,
  `id_usuario_sal` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `kilo` int(7) DEFAULT NULL,
  `documentacion_id` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `total` decimal(9,2) DEFAULT NULL,
  `estado` enum('E','S','D','A') COLLATE utf8_spanish_ci DEFAULT NULL COMMENT 'E=entrada, S=salida, D=diferido, A=anulado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `parque`
--

CREATE TABLE `parque` (
  `id_parque` int(11) NOT NULL,
  `organismo_area_id` varchar(5) COLLATE utf8_spanish_ci DEFAULT NULL,
  `descrip` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `parque`
--

INSERT INTO `parque` (`id_parque`, `organismo_area_id`, `descrip`) VALUES
(1, 'Y8K62', 'Parque Automotor Min.Salud');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `proveedores`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `proveedores` (
`denominacion` varchar(100)
,`cuit` varchar(11)
,`insc_rentas` varchar(15)
,`resp_iva` varchar(20)
,`resp_rentas` varchar(20)
,`domicilio` varchar(100)
,`cod_provincia` int(10)
,`tel1` varchar(30)
,`tel2` varchar(30)
,`celular` varchar(30)
,`contacto` varchar(50)
,`estado` enum('S','N')
,`fecha_tope_susp` date
,`observaciones` varchar(100)
,`cod_proveedor` int(11)
,`dni` enum('S','N')
,`bienes` enum('S','N')
,`contrato_sociedad` enum('S','N')
,`estado_contable` enum('S','N')
,`anteced_comerciales` enum('S','N')
,`afip` enum('S','N')
,`dgr` enum('S','N')
,`conducta_fiscal` enum('S','N')
,`hab_broma_municip` enum('S','N')
,`hab_farmacia` enum('S','N')
,`reg_pub_comercio` enum('S','N')
,`reg_prop_inmueble` enum('S','N')
,`reg_prop_automotor` enum('S','N')
,`enregla` enum('S','N')
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `razones_sociales`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `razones_sociales` (
`cod_razon_social` int(11)
,`cod_proveedor` int(11)
,`razon_social` varchar(250)
,`estado` enum('A','B')
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reparacion`
--

CREATE TABLE `reparacion` (
  `id_reparacion` int(11) NOT NULL,
  `id_movimiento` int(11) DEFAULT NULL,
  `id_tipo_reparacion` int(11) DEFAULT NULL,
  `costo` decimal(9,2) DEFAULT NULL,
  `cantidad` smallint(6) DEFAULT NULL,
  `total` decimal(9,2) DEFAULT NULL,
  `observa` text COLLATE utf8_spanish_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `taller`
--

CREATE TABLE `taller` (
  `cod_razon_social` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `taller`
--

INSERT INTO `taller` (`cod_razon_social`) VALUES
(6),
(7502),
(8870),
(731),
(157),
(5948),
(6239),
(2053),
(8777),
(4161),
(1671),
(43),
(9168),
(3852),
(9397),
(9544),
(1926),
(9544),
(9025),
(9662),
(9662),
(1680);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_incidente`
--

CREATE TABLE `tipo_incidente` (
  `id_tipo_incidente` int(11) NOT NULL,
  `descrip` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tipo_incidente`
--

INSERT INTO `tipo_incidente` (`id_tipo_incidente`, `descrip`) VALUES
(1, 'Genérico'),
(2, 'SINIESTROS'),
(3, 'coniestros 3'),
(4, 'ffff'),
(5, 'ferito con');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_reparacion`
--

CREATE TABLE `tipo_reparacion` (
  `id_tipo_reparacion` int(11) NOT NULL,
  `descrip` varchar(200) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_vehiculo`
--

CREATE TABLE `tipo_vehiculo` (
  `id_tipo_vehiculo` int(11) NOT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tipo_vehiculo`
--

INSERT INTO `tipo_vehiculo` (`id_tipo_vehiculo`, `descrip`) VALUES
(1, 'AMBULANCIA'),
(2, 'AUTO'),
(3, 'CAMIONETA CABINA SIMPLE'),
(4, 'CAMION'),
(5, 'UNIDAD OPERATIVA'),
(6, 'FURGON'),
(7, 'ACOPLADO'),
(8, 'CAMIONETA DOBLE CABINA'),
(9, 'MINIBUS'),
(10, 'CAMIONETA RURAL'),
(11, 'CAMIONETA CON CUPULA'),
(12, 'CAMION FRONTAL'),
(13, 'JEEP'),
(14, 'TRANSPORTE DE PASAJEROS'),
(15, 'TRACTOR'),
(17, 'UNIDAD CORONARIA'),
(18, 'TRAILER LABORATORIO'),
(19, 'TRAILER RADIOLOGICO'),
(20, 'TRAILER CLINICO'),
(21, 'MORGUERA'),
(22, 'AUTOELEVADOR'),
(23, 'Nuevo (23)'),
(24, 'Nuevo (24)'),
(25, 'Helicotero sin pasajero'),
(26, 'Helicotero con pasajero'),
(27, 'Avion'),
(28, 'Avion sin alas'),
(29, 'Avion con alas'),
(30, 'Tren'),
(31, 'Tren sin pasaje'),
(32, 'Tren con pasaje'),
(33, 'Caballo'),
(34, 'Caballo sin gente'),
(35, 'mula'),
(36, 'mula sin gente'),
(37, 'mula con gente'),
(38, 'preva con gente');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `unipresu`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `unipresu` (
`cod_up` int(11)
,`codigo` varchar(50)
,`nombre` varchar(250)
,`version` int(11)
,`estado` enum('A','B')
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculo`
--

CREATE TABLE `vehiculo` (
  `id_vehiculo` int(11) NOT NULL,
  `nro_patente` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nro_motor` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_tipo_vehiculo` int(11) DEFAULT NULL,
  `modelo` smallint(6) DEFAULT NULL,
  `marca` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nro_chasis` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `organismo_area_id` varchar(5) COLLATE utf8_spanish_ci DEFAULT NULL,
  `observa` mediumtext COLLATE utf8_spanish_ci,
  `id_parque` int(11) DEFAULT NULL,
  `total` decimal(9,2) DEFAULT NULL,
  `estado` enum('E','S','T') COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `_auditoria`
--

CREATE TABLE `_auditoria` (
  `id_auditoria` int(11) NOT NULL,
  `fecha` datetime DEFAULT NULL,
  `sql_texto` text COLLATE utf8_spanish_ci,
  `id` int(11) DEFAULT NULL,
  `tag` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `usuario` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `_auditoria`
--

INSERT INTO `_auditoria` (`id_auditoria`, `fecha`, `sql_texto`, `id`, `tag`, `usuario`) VALUES
(1, '2018-12-02 00:51:10', 'UPDATE vehiculo SET id_vehiculo=\'862\', nro_patente=\'ILH-538\', nro_motor=\'538\', id_tipo_vehiculo=\'2\', modelo=\'2010\', marca=\'Renault Symbol\', nro_chasis=\'538\', organismo_area_id=\'ZM7T6\', observa=\'Este es el Symbol modificado\', id_parque=\'1\' WHERE id_vehiculo=862', 862, 'update_vehiculo', 'rsantiagopaz');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `_departamentos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `_departamentos` (
`departamento_id` int(11)
,`departamento` varchar(200)
,`codigo_indec` varchar(50)
,`provincia_id` int(11)
,`provincia_id_indec` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `_organismos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `_organismos` (
`organismo_id` char(10)
,`organismo` char(100)
,`organismo_tipo` char(1)
,`domicilio` char(50)
,`telefonos` char(50)
,`localidad_id` char(5)
,`organismo_expediente_codigo` int(3)
,`organismo_expediente_ultimonumero` int(5)
,`organismo_expediente_ultimoano` int(4)
,`estado` char(1)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `_organismos_areas`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `_organismos_areas` (
`organismo_area_id` varchar(5)
,`organismo_area_tipo_id` char(2)
,`organismo_area` varchar(100)
,`organismo_area_descripcion` text
,`organismo_id` varchar(10)
,`organismo_area_estado` char(1)
,`organismo_area_mesa_entrada` char(1)
,`organismo_area_archivo` char(1)
,`grupo_dominio_red` varchar(15)
,`organismo_areas_id_tipologia` varchar(1)
,`organismo_areas_id_categoria` varchar(1)
,`organismo_areas_id_depend_adm` varchar(2)
,`organismo_areas_id_departamento` varchar(3)
,`organismo_areas_codigo_provincial` varchar(6)
,`organismo_areas_efector_codigo_propio` varchar(20)
,`id_area_operativa` int(11)
,`referente_area_operativa` smallint(1)
,`remediar` smallint(6)
,`codigo_remediar` varchar(250)
,`publico` enum('S','N')
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `_personal`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `_personal` (
`id_personal` int(11)
,`id_relac_contractual` int(11)
,`id_persona` int(11)
,`id_areas_servicios` int(11)
,`prefijo` int(2)
,`dni` int(11)
,`sufijo` int(11)
,`apenom` varchar(200)
,`jurisdiccion` int(11)
,`programa` int(11)
,`subprograma` int(11)
,`actividad` int(11)
,`codigo_lugar_pago` int(11)
,`denominacion_lugar_pago` varchar(200)
,`control` int(11)
,`denominacion_cargo` varchar(200)
,`categoria` varchar(200)
,`planta` varchar(200)
,`total_haber_con_aporte` float(10,2)
,`total_haber_sin_aporte` float(10,2)
,`total_descuentos` float(10,2)
,`liquido` float(10,2)
,`c_categoria` varchar(100)
,`c_lugar_trabajo` varchar(100)
,`c_importe` float(10,2)
,`c_cuit` varchar(11)
,`c_fecha_inicio` date
,`borrado` tinyint(4)
,`timestamp` timestamp
,`fecha_ing_establecim` date
,`localidad_id` char(5)
,`relacion_contractual_otro` varchar(100)
,`asistencial` enum('S','N')
,`id_profesion` int(11)
,`carga_horaria_semanal` int(11)
,`horas_rotativas` int(11)
,`relevado` enum('S','N')
,`fecha_relevamiento` date
,`codigo_002_sueldos_2013_03` decimal(8,2)
,`codigo_002` decimal(8,2)
,`funcionario` tinyint(1)
,`eximir_tope_viatico` tinyint(1)
,`organismo_externo` enum('S','N')
,`vinculo_precario` int(1)
,`comentarios_vinculo` text
);

-- --------------------------------------------------------

--
-- Estructura para la vista `001_documentaciones`
--
DROP TABLE IF EXISTS `001_documentaciones`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `001_documentaciones`  AS  select `salud1`.`001_documentaciones`.`documentacion_id` AS `documentacion_id`,`salud1`.`001_documentaciones`.`documentacion_tmp_iniciador` AS `documentacion_tmp_iniciador`,`salud1`.`001_documentaciones`.`documentacion_tmp_asunto` AS `documentacion_tmp_asunto`,`salud1`.`001_documentaciones`.`documentacion_tmp_SYSusuario` AS `documentacion_tmp_SYSusuario`,`salud1`.`001_documentaciones`.`documentacion_tmp_estado` AS `documentacion_tmp_estado`,`salud1`.`001_documentaciones`.`documentacion_tipo_id` AS `documentacion_tipo_id`,`salud1`.`001_documentaciones`.`documentacion_tipo_otro` AS `documentacion_tipo_otro`,`salud1`.`001_documentaciones`.`documentacion_numero` AS `documentacion_numero`,`salud1`.`001_documentaciones`.`documentacion_numero_ano` AS `documentacion_numero_ano`,`salud1`.`001_documentaciones`.`documentacion_numero_documentacion_tipo_id` AS `documentacion_numero_documentacion_tipo_id`,`salud1`.`001_documentaciones`.`documentacion_organismo_area_id` AS `documentacion_organismo_area_id`,`salud1`.`001_documentaciones`.`iniciador_tipo` AS `iniciador_tipo`,`salud1`.`001_documentaciones`.`iniciador_persona_id` AS `iniciador_persona_id`,`salud1`.`001_documentaciones`.`iniciador_persona_id_anterior` AS `iniciador_persona_id_anterior`,`salud1`.`001_documentaciones`.`iniciador_persona_id_nuevo` AS `iniciador_persona_id_nuevo`,`salud1`.`001_documentaciones`.`iniciador_organismo_id` AS `iniciador_organismo_id`,`salud1`.`001_documentaciones`.`iniciador_organismo_area_id` AS `iniciador_organismo_area_id`,`salud1`.`001_documentaciones`.`iniciador_otro` AS `iniciador_otro`,`salud1`.`001_documentaciones`.`expediente_numero` AS `expediente_numero`,`salud1`.`001_documentaciones`.`expediente_codigo` AS `expediente_codigo`,`salud1`.`001_documentaciones`.`expediente_ano` AS `expediente_ano`,`salud1`.`001_documentaciones`.`expediente_fecha` AS `expediente_fecha`,`salud1`.`001_documentaciones`.`expediente_SYSusuario` AS `expediente_SYSusuario`,`salud1`.`001_documentaciones`.`expediente_estado` AS `expediente_estado`,`salud1`.`001_documentaciones`.`expediente_estado_suspendido_hasta` AS `expediente_estado_suspendido_hasta`,`salud1`.`001_documentaciones`.`expediente_estado_suspendido_hasta_SYSusuario` AS `expediente_estado_suspendido_hasta_SYSusuario`,`salud1`.`001_documentaciones`.`documentacion_asunto` AS `documentacion_asunto`,`salud1`.`001_documentaciones`.`documentacion_asunto_tipo_id` AS `documentacion_asunto_tipo_id`,`salud1`.`001_documentaciones`.`documentacion_asunto_tipo_otro` AS `documentacion_asunto_tipo_otro`,`salud1`.`001_documentaciones`.`documentacion_fecha_inicio` AS `documentacion_fecha_inicio`,`salud1`.`001_documentaciones`.`documentacion_fecha` AS `documentacion_fecha`,`salud1`.`001_documentaciones`.`documentacion_hora` AS `documentacion_hora`,`salud1`.`001_documentaciones`.`documentacion_folios` AS `documentacion_folios`,`salud1`.`001_documentaciones`.`documentacion_SYSusuario` AS `documentacion_SYSusuario`,`salud1`.`001_documentaciones`.`glosado_a_documentacion_id` AS `glosado_a_documentacion_id`,`salud1`.`001_documentaciones`.`glosados` AS `glosados`,`salud1`.`001_documentaciones`.`_alta_id` AS `_alta_id`,`salud1`.`001_documentaciones`.`seguimiento_id` AS `seguimiento_id`,`salud1`.`001_documentaciones`.`referencia_de_busqueda` AS `referencia_de_busqueda`,`salud1`.`001_documentaciones`.`id_formulario` AS `id_formulario`,`salud1`.`001_documentaciones`.`id_rendicion` AS `id_rendicion` from `salud1`.`001_documentaciones` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `001_documentaciones_tipos`
--
DROP TABLE IF EXISTS `001_documentaciones_tipos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `001_documentaciones_tipos`  AS  select `salud1`.`001_documentaciones_tipos`.`documentacion_tipo_id` AS `documentacion_tipo_id`,`salud1`.`001_documentaciones_tipos`.`documentacion_tipo` AS `documentacion_tipo`,`salud1`.`001_documentaciones_tipos`.`documentacion_tipo_orden_aparicion` AS `documentacion_tipo_orden_aparicion` from `salud1`.`001_documentaciones_tipos` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `proveedores`
--
DROP TABLE IF EXISTS `proveedores`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `proveedores`  AS  select `019`.`proveedores`.`denominacion` AS `denominacion`,`019`.`proveedores`.`cuit` AS `cuit`,`019`.`proveedores`.`insc_rentas` AS `insc_rentas`,`019`.`proveedores`.`resp_iva` AS `resp_iva`,`019`.`proveedores`.`resp_rentas` AS `resp_rentas`,`019`.`proveedores`.`domicilio` AS `domicilio`,`019`.`proveedores`.`cod_provincia` AS `cod_provincia`,`019`.`proveedores`.`tel1` AS `tel1`,`019`.`proveedores`.`tel2` AS `tel2`,`019`.`proveedores`.`celular` AS `celular`,`019`.`proveedores`.`contacto` AS `contacto`,`019`.`proveedores`.`estado` AS `estado`,`019`.`proveedores`.`fecha_tope_susp` AS `fecha_tope_susp`,`019`.`proveedores`.`observaciones` AS `observaciones`,`019`.`proveedores`.`cod_proveedor` AS `cod_proveedor`,`019`.`proveedores`.`dni` AS `dni`,`019`.`proveedores`.`bienes` AS `bienes`,`019`.`proveedores`.`contrato_sociedad` AS `contrato_sociedad`,`019`.`proveedores`.`estado_contable` AS `estado_contable`,`019`.`proveedores`.`anteced_comerciales` AS `anteced_comerciales`,`019`.`proveedores`.`afip` AS `afip`,`019`.`proveedores`.`dgr` AS `dgr`,`019`.`proveedores`.`conducta_fiscal` AS `conducta_fiscal`,`019`.`proveedores`.`hab_broma_municip` AS `hab_broma_municip`,`019`.`proveedores`.`hab_farmacia` AS `hab_farmacia`,`019`.`proveedores`.`reg_pub_comercio` AS `reg_pub_comercio`,`019`.`proveedores`.`reg_prop_inmueble` AS `reg_prop_inmueble`,`019`.`proveedores`.`reg_prop_automotor` AS `reg_prop_automotor`,`019`.`proveedores`.`enregla` AS `enregla` from `019`.`proveedores` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `razones_sociales`
--
DROP TABLE IF EXISTS `razones_sociales`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `razones_sociales`  AS  select `019`.`razones_sociales`.`cod_razon_social` AS `cod_razon_social`,`019`.`razones_sociales`.`cod_proveedor` AS `cod_proveedor`,`019`.`razones_sociales`.`razon_social` AS `razon_social`,`019`.`razones_sociales`.`estado` AS `estado` from `019`.`razones_sociales` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `unipresu`
--
DROP TABLE IF EXISTS `unipresu`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `unipresu`  AS  select `019`.`unipresu`.`cod_up` AS `cod_up`,`019`.`unipresu`.`codigo` AS `codigo`,`019`.`unipresu`.`nombre` AS `nombre`,`019`.`unipresu`.`version` AS `version`,`019`.`unipresu`.`estado` AS `estado` from `019`.`unipresu` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `_departamentos`
--
DROP TABLE IF EXISTS `_departamentos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `_departamentos`  AS  select `salud1`.`_departamentos`.`departamento_id` AS `departamento_id`,`salud1`.`_departamentos`.`departamento` AS `departamento`,`salud1`.`_departamentos`.`codigo_indec` AS `codigo_indec`,`salud1`.`_departamentos`.`provincia_id` AS `provincia_id`,`salud1`.`_departamentos`.`provincia_id_indec` AS `provincia_id_indec` from `salud1`.`_departamentos` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `_organismos`
--
DROP TABLE IF EXISTS `_organismos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `_organismos`  AS  select `salud1`.`_organismos`.`organismo_id` AS `organismo_id`,`salud1`.`_organismos`.`organismo` AS `organismo`,`salud1`.`_organismos`.`organismo_tipo` AS `organismo_tipo`,`salud1`.`_organismos`.`domicilio` AS `domicilio`,`salud1`.`_organismos`.`telefonos` AS `telefonos`,`salud1`.`_organismos`.`localidad_id` AS `localidad_id`,`salud1`.`_organismos`.`organismo_expediente_codigo` AS `organismo_expediente_codigo`,`salud1`.`_organismos`.`organismo_expediente_ultimonumero` AS `organismo_expediente_ultimonumero`,`salud1`.`_organismos`.`organismo_expediente_ultimoano` AS `organismo_expediente_ultimoano`,`salud1`.`_organismos`.`estado` AS `estado` from `salud1`.`_organismos` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `_organismos_areas`
--
DROP TABLE IF EXISTS `_organismos_areas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `_organismos_areas`  AS  select `salud1`.`_organismos_areas`.`organismo_area_id` AS `organismo_area_id`,`salud1`.`_organismos_areas`.`organismo_area_tipo_id` AS `organismo_area_tipo_id`,`salud1`.`_organismos_areas`.`organismo_area` AS `organismo_area`,`salud1`.`_organismos_areas`.`organismo_area_descripcion` AS `organismo_area_descripcion`,`salud1`.`_organismos_areas`.`organismo_id` AS `organismo_id`,`salud1`.`_organismos_areas`.`organismo_area_estado` AS `organismo_area_estado`,`salud1`.`_organismos_areas`.`organismo_area_mesa_entrada` AS `organismo_area_mesa_entrada`,`salud1`.`_organismos_areas`.`organismo_area_archivo` AS `organismo_area_archivo`,`salud1`.`_organismos_areas`.`grupo_dominio_red` AS `grupo_dominio_red`,`salud1`.`_organismos_areas`.`organismo_areas_id_tipologia` AS `organismo_areas_id_tipologia`,`salud1`.`_organismos_areas`.`organismo_areas_id_categoria` AS `organismo_areas_id_categoria`,`salud1`.`_organismos_areas`.`organismo_areas_id_depend_adm` AS `organismo_areas_id_depend_adm`,`salud1`.`_organismos_areas`.`organismo_areas_id_departamento` AS `organismo_areas_id_departamento`,`salud1`.`_organismos_areas`.`organismo_areas_codigo_provincial` AS `organismo_areas_codigo_provincial`,`salud1`.`_organismos_areas`.`organismo_areas_efector_codigo_propio` AS `organismo_areas_efector_codigo_propio`,`salud1`.`_organismos_areas`.`id_area_operativa` AS `id_area_operativa`,`salud1`.`_organismos_areas`.`referente_area_operativa` AS `referente_area_operativa`,`salud1`.`_organismos_areas`.`remediar` AS `remediar`,`salud1`.`_organismos_areas`.`codigo_remediar` AS `codigo_remediar`,`salud1`.`_organismos_areas`.`publico` AS `publico` from `salud1`.`_organismos_areas` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `_personal`
--
DROP TABLE IF EXISTS `_personal`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `_personal`  AS  select `salud1`.`_personal`.`id_personal` AS `id_personal`,`salud1`.`_personal`.`id_relac_contractual` AS `id_relac_contractual`,`salud1`.`_personal`.`id_persona` AS `id_persona`,`salud1`.`_personal`.`id_areas_servicios` AS `id_areas_servicios`,`salud1`.`_personal`.`prefijo` AS `prefijo`,`salud1`.`_personal`.`dni` AS `dni`,`salud1`.`_personal`.`sufijo` AS `sufijo`,`salud1`.`_personal`.`apenom` AS `apenom`,`salud1`.`_personal`.`jurisdiccion` AS `jurisdiccion`,`salud1`.`_personal`.`programa` AS `programa`,`salud1`.`_personal`.`subprograma` AS `subprograma`,`salud1`.`_personal`.`actividad` AS `actividad`,`salud1`.`_personal`.`codigo_lugar_pago` AS `codigo_lugar_pago`,`salud1`.`_personal`.`denominacion_lugar_pago` AS `denominacion_lugar_pago`,`salud1`.`_personal`.`control` AS `control`,`salud1`.`_personal`.`denominacion_cargo` AS `denominacion_cargo`,`salud1`.`_personal`.`categoria` AS `categoria`,`salud1`.`_personal`.`planta` AS `planta`,`salud1`.`_personal`.`total_haber_con_aporte` AS `total_haber_con_aporte`,`salud1`.`_personal`.`total_haber_sin_aporte` AS `total_haber_sin_aporte`,`salud1`.`_personal`.`total_descuentos` AS `total_descuentos`,`salud1`.`_personal`.`liquido` AS `liquido`,`salud1`.`_personal`.`c_categoria` AS `c_categoria`,`salud1`.`_personal`.`c_lugar_trabajo` AS `c_lugar_trabajo`,`salud1`.`_personal`.`c_importe` AS `c_importe`,`salud1`.`_personal`.`c_cuit` AS `c_cuit`,`salud1`.`_personal`.`c_fecha_inicio` AS `c_fecha_inicio`,`salud1`.`_personal`.`borrado` AS `borrado`,`salud1`.`_personal`.`timestamp` AS `timestamp`,`salud1`.`_personal`.`fecha_ing_establecim` AS `fecha_ing_establecim`,`salud1`.`_personal`.`localidad_id` AS `localidad_id`,`salud1`.`_personal`.`relacion_contractual_otro` AS `relacion_contractual_otro`,`salud1`.`_personal`.`asistencial` AS `asistencial`,`salud1`.`_personal`.`id_profesion` AS `id_profesion`,`salud1`.`_personal`.`carga_horaria_semanal` AS `carga_horaria_semanal`,`salud1`.`_personal`.`horas_rotativas` AS `horas_rotativas`,`salud1`.`_personal`.`relevado` AS `relevado`,`salud1`.`_personal`.`fecha_relevamiento` AS `fecha_relevamiento`,`salud1`.`_personal`.`codigo_002_sueldos_2013_03` AS `codigo_002_sueldos_2013_03`,`salud1`.`_personal`.`codigo_002` AS `codigo_002`,`salud1`.`_personal`.`funcionario` AS `funcionario`,`salud1`.`_personal`.`eximir_tope_viatico` AS `eximir_tope_viatico`,`salud1`.`_personal`.`organismo_externo` AS `organismo_externo`,`salud1`.`_personal`.`vinculo_precario` AS `vinculo_precario`,`salud1`.`_personal`.`comentarios_vinculo` AS `comentarios_vinculo` from `salud1`.`_personal` ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `chofer`
--
ALTER TABLE `chofer`
  ADD PRIMARY KEY (`id_chofer`);

--
-- Indices de la tabla `entsal`
--
ALTER TABLE `entsal`
  ADD PRIMARY KEY (`id_entsal`);

--
-- Indices de la tabla `incidente`
--
ALTER TABLE `incidente`
  ADD PRIMARY KEY (`id_incidente`);

--
-- Indices de la tabla `movimiento`
--
ALTER TABLE `movimiento`
  ADD PRIMARY KEY (`id_movimiento`);

--
-- Indices de la tabla `parque`
--
ALTER TABLE `parque`
  ADD PRIMARY KEY (`id_parque`);

--
-- Indices de la tabla `reparacion`
--
ALTER TABLE `reparacion`
  ADD PRIMARY KEY (`id_reparacion`);

--
-- Indices de la tabla `tipo_incidente`
--
ALTER TABLE `tipo_incidente`
  ADD PRIMARY KEY (`id_tipo_incidente`);

--
-- Indices de la tabla `tipo_reparacion`
--
ALTER TABLE `tipo_reparacion`
  ADD PRIMARY KEY (`id_tipo_reparacion`);

--
-- Indices de la tabla `tipo_vehiculo`
--
ALTER TABLE `tipo_vehiculo`
  ADD PRIMARY KEY (`id_tipo_vehiculo`);

--
-- Indices de la tabla `vehiculo`
--
ALTER TABLE `vehiculo`
  ADD PRIMARY KEY (`id_vehiculo`);

--
-- Indices de la tabla `_auditoria`
--
ALTER TABLE `_auditoria`
  ADD PRIMARY KEY (`id_auditoria`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `chofer`
--
ALTER TABLE `chofer`
  MODIFY `id_chofer` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `entsal`
--
ALTER TABLE `entsal`
  MODIFY `id_entsal` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `incidente`
--
ALTER TABLE `incidente`
  MODIFY `id_incidente` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `movimiento`
--
ALTER TABLE `movimiento`
  MODIFY `id_movimiento` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `parque`
--
ALTER TABLE `parque`
  MODIFY `id_parque` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `reparacion`
--
ALTER TABLE `reparacion`
  MODIFY `id_reparacion` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tipo_incidente`
--
ALTER TABLE `tipo_incidente`
  MODIFY `id_tipo_incidente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `tipo_reparacion`
--
ALTER TABLE `tipo_reparacion`
  MODIFY `id_tipo_reparacion` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tipo_vehiculo`
--
ALTER TABLE `tipo_vehiculo`
  MODIFY `id_tipo_vehiculo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT de la tabla `vehiculo`
--
ALTER TABLE `vehiculo`
  MODIFY `id_vehiculo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `_auditoria`
--
ALTER TABLE `_auditoria`
  MODIFY `id_auditoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
